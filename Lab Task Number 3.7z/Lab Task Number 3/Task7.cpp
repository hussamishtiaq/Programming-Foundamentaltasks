#include<iostream>
using namespace std;
int main(){
    if (0)
cout << "0 is true";
else
cout << "0 is false";
cout << endl;// The output of the first if statement is "0 is false" because the 0 makes the if  statement false 
if (1)
cout << "1 is true";
else
cout << "1 is false";
cout << endl;//The ouput of the second if statement is "1 is true " because any number rather then 0 consider as true  
 if (-1)
cout << "-1 is true";
else
cout << "-1 is false";
cout << endl;}//The ouput of the second if statement is "1 is true " because any number rather then 0 consider as true  
