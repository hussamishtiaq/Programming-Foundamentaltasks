#include<iostream>
using namespace std;
int main(){
    int x;
    printf("Enter the value for x:");
    cin>>x;
   if(x>1&&x<3){
    printf("This qudratic expression is negative");
   }
   else{
    printf("This quadratic expression is positive");
   }
}