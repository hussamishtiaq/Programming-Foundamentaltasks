#include<iostream>
using namespace std;
int main(){
    int number;
    cin>>number;
    if(number>100){
        printf("High");
    }
    else{
        printf("Low");
    }
}